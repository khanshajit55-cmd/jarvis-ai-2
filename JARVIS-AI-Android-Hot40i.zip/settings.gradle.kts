rootProject.name = "JarvisAI"
include(":app")
